import { businesses, contact, getBusiness } from './data.js';
import './styles.css';

const app = document.querySelector('#app');

const icon = (name, size = 18) => {
  const paths = {
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    arrowUp: '<path d="M7 17 17 7M7 7h10v10"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    phone: '<path d="M6.7 3.5 9 3l2 4-1.8 1.4a13.2 13.2 0 0 0 6.4 6.4L17 13l4 2-.5 2.3A2.4 2.4 0 0 1 18.2 19C10.4 18.1 5.9 13.6 5 5.8A2.4 2.4 0 0 1 6.7 3.5Z"/>',
    mail: '<path d="M4 6h16v12H4zM4 7l8 6 8-6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.8 12h16.4M12 3.5c2.2 2.3 3.2 5.1 3.2 8.5s-1 6.2-3.2 8.5c-2.2-2.3-3.2-5.1-3.2-8.5s1-6.2 3.2-8.5Z"/>',
    check: '<path d="m5 12 4 4L19 6"/>'
  };
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.arrow}</svg>`;
};

const routeLink = (href, label, className = '') => `<a class="${className}" href="${href}" data-route>${label}</a>`;

const header = (active = '') => `
  <header class="site-header">
    <div class="container header-inner">
      ${routeLink('/', `<span class="brand-lockup"><img src="/bhojraj-logo.png" alt="Bhojraj India Group logo" /><span class="brand-lockup__words"><strong>BHOJRAJ</strong><small>INDIA GROUP</small></span></span>`, 'brand')}
      <nav class="desktop-nav" aria-label="Primary navigation">
        ${routeLink('/', 'Home', active === 'home' ? 'is-active' : '')}
        ${routeLink('/businesses', 'Businesses', active === 'businesses' ? 'is-active' : '')}
        ${routeLink('/about', 'About', active === 'about' ? 'is-active' : '')}
      </nav>
      <div class="header-actions">
        <a class="header-contact" href="tel:${contact.phone}">${icon('phone', 15)} <span>Talk to us</span></a>
        <button class="menu-toggle" type="button" aria-label="Open navigation" aria-expanded="false">${icon('menu', 22)}</button>
      </div>
    </div>
    <div class="mobile-nav" aria-hidden="true">
      <div class="mobile-nav__inner">
        ${routeLink('/', 'Home', 'mobile-nav__link')}
        ${routeLink('/businesses', 'Businesses', 'mobile-nav__link')}
        ${routeLink('/about', 'About', 'mobile-nav__link')}
        <a class="button button--gold mobile-nav__cta" href="${contact.whatsapp}" target="_blank" rel="noreferrer">Start a conversation ${icon('arrow', 16)}</a>
      </div>
    </div>
  </header>
`;

const footer = () => `
  <footer class="site-footer">
    <div class="container footer-top">
      <div class="footer-brand">
        <div class="eyebrow eyebrow--gold">BHOJRAJ INDIA GROUP</div>
        <h2>A group with<br /><em>range and reason.</em></h2>
      </div>
      <div class="footer-cta">
        <p>For partnerships, ideas, and new possibilities.</p>
        <a class="button button--light" href="mailto:${contact.email}">Start a conversation ${icon('arrow', 16)}</a>
      </div>
    </div>
    <div class="container footer-bottom">
      <span>© 2026 Bhojraj India Group · Indore, Madhya Pradesh</span>
      <div class="footer-links"><a href="tel:${contact.phone}">${contact.phoneDisplay}</a><a href="mailto:${contact.email}">${contact.email}</a></div>
    </div>
  </footer>
`;

const businessCard = (business, compact = false) => `
  <a class="business-card ${compact ? 'business-card--compact' : ''} accent-${business.accent}" href="/business/${business.slug}" data-route>
    <div class="business-card__top"><span>${business.index}</span><span class="business-card__glyph">${business.glyph}</span></div>
    <div class="business-card__body"><span class="eyebrow">Bhojraj India</span><h3>${business.label}</h3><p>${business.short}</p></div>
    <div class="business-card__foot"><span>Explore vertical</span>${icon('arrowUp', 17)}</div>
  </a>
`;

const heroOrb = () => `
  <div class="hero-orb" aria-hidden="true">
    <div class="orb-core"></div><span class="orb-label orb-label--one">MEDIA</span><span class="orb-label orb-label--two">TRADE</span><span class="orb-label orb-label--three">PEOPLE</span>
    <div class="orb-ring orb-ring--one"></div><div class="orb-ring orb-ring--two"></div><div class="orb-ring orb-ring--three"></div>
  </div>
`;

const renderHome = () => `
  ${header('home')}
  <main>
    <section class="hero hero--home">
      <div class="container hero-grid">
        <div class="hero-copy reveal">
          <div class="eyebrow eyebrow--gold"><span class="eyebrow-dot"></span>Indore · Madhya Pradesh · India</div>
          <h1>Many<br /><span>ventures.</span><br />One <em>vision.</em></h1>
          <p class="hero-lede">Bhojraj India Group brings media, trade, people, and enterprise into one connected ecosystem — built for the world we are becoming.</p>
          <div class="hero-actions"><a class="button button--gold" href="/businesses" data-route>Explore the group ${icon('arrow', 16)}</a><a class="text-link" href="/about" data-route>Meet the group ${icon('arrow', 16)}</a></div>
        </div>
        <div class="hero-visual reveal reveal--delay">${heroOrb()}<div class="hero-note"><span>01</span><p>Where enterprise<br />meets excellence.</p></div></div>
      </div>
      <div class="container hero-foot"><span class="hero-foot__line"></span><span>Scroll to explore</span><span class="hero-foot__line hero-foot__line--short"></span><span class="hero-foot__year">2026 <b>↗</b></span></div>
    </section>

    <section class="section section--intro" id="intro">
      <div class="container intro-grid">
        <div class="section-index reveal">/ 01</div>
        <div class="intro-copy reveal reveal--delay"><div class="eyebrow">The idea</div><h2>Build with intent.<br /><span>Move with range.</span></h2><p>Not a holding company in the conventional sense. A working network of businesses with one shared standard: thoughtful work, useful ambition, and a bias toward making things better.</p><a class="text-link" href="/about" data-route>Read our story ${icon('arrow', 16)}</a></div>
        <div class="intro-stat reveal reveal--delay-2"><strong>09</strong><span>business verticals</span><small>connected by a common point of view</small></div>
      </div>
    </section>

    <section class="section section--businesses">
      <div class="container">
        <div class="section-heading reveal"><div><div class="eyebrow eyebrow--gold">The portfolio</div><h2>Different doors.<br /><span>Same standard.</span></h2></div><a class="text-link text-link--desktop" href="/businesses" data-route>View all businesses ${icon('arrow', 16)}</a></div>
        <div class="business-grid">${businesses.slice(0, 6).map((business) => businessCard(business)).join('')}</div>
        <a class="button button--outline mobile-only" href="/businesses" data-route>View all businesses ${icon('arrow', 16)}</a>
      </div>
    </section>

    <section class="signal-section">
      <div class="container signal-grid"><div class="signal-copy reveal"><div class="eyebrow eyebrow--gold">A connected way of working</div><h2>Every vertical adds<br /><em>a new signal.</em></h2><p>From a story to a supply chain, a conversation to a construction site — the group’s advantage lives in the connections between its businesses.</p></div><div class="signal-map reveal reveal--delay"><div class="signal-node signal-node--center">B<span>IG</span></div><div class="signal-node signal-node--a">MEDIA</div><div class="signal-node signal-node--b">TRADE</div><div class="signal-node signal-node--c">PEOPLE</div><div class="signal-node signal-node--d">IDEAS</div><span class="signal-line signal-line--a"></span><span class="signal-line signal-line--b"></span><span class="signal-line signal-line--c"></span><span class="signal-line signal-line--d"></span></div></div>
    </section>

    <section class="section section--contact"><div class="container contact-card"><div><div class="eyebrow eyebrow--gold">Let’s make something useful</div><h2>Have a good<br /><em>idea?</em></h2></div><div class="contact-card__right"><p>Whether you are building a business, looking for the right partner, or simply want to compare notes — we would like to hear from you.</p><div class="contact-card__actions"><a class="button button--gold" href="${contact.whatsapp}" target="_blank" rel="noreferrer">WhatsApp us ${icon('arrow', 16)}</a><a class="text-link" href="mailto:${contact.email}">Send an email ${icon('arrow', 16)}</a></div></div></div></section>
  </main>
  ${footer()}
`;

const renderBusinesses = () => `
  ${header('businesses')}
  <main>
    <section class="page-hero"><div class="container page-hero__inner"><div class="eyebrow eyebrow--gold">/ 02 · The portfolio</div><h1>One group.<br /><em>Many ways</em> to make<br />an impact.</h1><p>Explore the businesses that make up Bhojraj India Group — each with its own rhythm, all moving in the same direction.</p></div><div class="page-hero__mark">B/IG</div></section>
    <section class="section section--directory"><div class="container"><div class="directory-tools"><div class="eyebrow">09 verticals · one ecosystem</div><div class="filter-set" role="group" aria-label="Filter businesses"><button class="filter-button is-active" data-filter="all">All</button><button class="filter-button" data-filter="people">People</button><button class="filter-button" data-filter="ideas">Ideas</button><button class="filter-button" data-filter="enterprise">Enterprise</button></div></div><div class="directory-grid">${businesses.map((business) => businessCard(business)).join('')}</div></div></section>
    <section class="section section--directory-note"><div class="container note-grid"><div class="section-index">/ 03</div><div><div class="eyebrow eyebrow--gold">A wider lens</div><h2>The opportunity is<br /><span>in the overlap.</span></h2><p>Our businesses are designed to stand on their own — and become more useful when they meet. That is where new partnerships, new products, and better outcomes tend to appear.</p></div></div></section>
  </main>
  ${footer()}
`;

const renderAbout = () => `
  ${header('about')}
  <main>
    <section class="page-hero page-hero--about"><div class="container page-hero__inner"><div class="eyebrow eyebrow--gold">/ 03 · The group</div><h1>Enterprise is<br /><em>a point of view.</em></h1><p>Bhojraj India Group is the work of building useful things, in public, over time.</p></div><div class="page-hero__stamp">EST.<br /><strong>INDIA</strong><br />2026</div></section>
    <section class="section section--story"><div class="container story-grid"><div class="story-aside"><div class="eyebrow">The short version</div><span class="story-quote">“Where enterprise meets excellence.”</span></div><div class="story-body"><h2>We are building a group for the space between <em>ambition</em> and action.</h2><p>Bhojraj India Group is a multi-business enterprise headquartered in Indore, Madhya Pradesh. We work across media, news, trade, industries, export and import, foods, workforce, magazine, and podcast — with each venture connected by a belief in thoughtful execution.</p><p>Our role is not to do everything. It is to find the right work, bring the right people together, and keep raising the standard on what follows.</p><div class="story-values"><div><span>01</span><strong>Curiosity</strong><p>Stay open to the next useful idea.</p></div><div><span>02</span><strong>Reliability</strong><p>Do the work people can count on.</p></div><div><span>03</span><strong>Range</strong><p>Move confidently across contexts.</p></div></div></div></div></section>
    <section class="statement-section"><div class="container statement-inner"><span class="statement-mark">B/IG</span><h2>“The best businesses<br />leave things <em>better</em><br />than they found them.”</h2><div class="statement-signature">Arjun Bhojraj <span>Founder · Bhojraj India Group</span></div></div></section>
    <section class="section section--contact section--contact-about"><div class="container contact-card"><div><div class="eyebrow eyebrow--gold">Start a conversation</div><h2>Good work<br /><em>travels.</em></h2></div><div class="contact-card__right"><p>Based in Indore, connected everywhere. Reach out with a question, an opportunity, or a direction you want to explore.</p><div class="contact-list"><a href="tel:${contact.phone}">${icon('phone', 16)} ${contact.phoneDisplay}</a><a href="mailto:${contact.email}">${icon('mail', 16)} ${contact.email}</a><a href="${contact.whatsapp}" target="_blank" rel="noreferrer">${icon('arrow', 16)} WhatsApp conversation</a></div></div></div></section>
  </main>
  ${footer()}
`;

const renderBusiness = (business) => `
  ${header('businesses')}
  <main>
    <section class="detail-hero accent-${business.accent}"><div class="container detail-hero__grid"><div class="detail-hero__copy"><a class="back-link" href="/businesses" data-route>${icon('arrow', 15)} Back to all businesses</a><div class="eyebrow eyebrow--gold">${business.index} / Bhojraj India Group</div><h1>${business.label}<br /><em>${business.kicker}</em></h1><p>${business.short}</p></div><div class="detail-hero__shape"><span>${business.glyph}</span><b>${business.index}</b></div></div></section>
    <section class="section section--detail-intro"><div class="container detail-intro-grid"><div class="section-index">/ ${business.index}</div><div><div class="eyebrow eyebrow--gold">The point of view</div><h2>${business.promise}</h2><p class="detail-lede">${business.description}</p><div class="detail-actions"><a class="button button--gold" href="${contact.whatsapp}" target="_blank" rel="noreferrer">Talk about this vertical ${icon('arrow', 16)}</a><a class="text-link" href="mailto:${contact.email}">Email Arjun ${icon('arrow', 16)}</a></div></div></div></section>
    <section class="detail-stats"><div class="container detail-stats__grid">${business.stats.map(([number, label]) => `<div class="detail-stat"><span>${number}</span><strong>${label}</strong></div>`).join('')}</div></section>
    <section class="section section--next"><div class="container"><div class="section-heading"><div><div class="eyebrow">Keep exploring</div><h2>There is more<br /><span>in the group.</span></h2></div><a class="text-link text-link--desktop" href="/businesses" data-route>See all verticals ${icon('arrow', 16)}</a></div><div class="next-businesses">${businesses.filter((item) => item.slug !== business.slug).slice(0, 3).map((item) => businessCard(item, true)).join('')}</div></div></section>
  </main>
  ${footer()}
`;

const renderNotFound = () => `${header()}<main class="not-found"><div class="container"><div class="eyebrow eyebrow--gold">404 / Detour</div><h1>That page took<br /><em>a different route.</em></h1><a class="button button--gold" href="/" data-route>Return home ${icon('arrow', 16)}</a></div></main>${footer()}`;

const getRoute = () => window.location.pathname.replace(/\/$/, '') || '/';

const render = () => {
  const path = getRoute();
  if (path === '/') app.innerHTML = renderHome();
  else if (path === '/businesses') app.innerHTML = renderBusinesses();
  else if (path === '/about') app.innerHTML = renderAbout();
  else if (path.startsWith('/business/')) {
    const business = getBusiness(path.split('/')[2]);
    app.innerHTML = business ? renderBusiness(business) : renderNotFound();
  } else app.innerHTML = renderNotFound();
  window.scrollTo({ top: 0, behavior: 'instant' });
  bindInteractions();
};

const bindInteractions = () => {
  document.querySelectorAll('[data-route]').forEach((link) => {
    link.addEventListener('click', (event) => {
      const href = link.getAttribute('href');
      if (!href || href.startsWith('http') || href.startsWith('mailto:') || href.startsWith('tel:')) return;
      event.preventDefault();
      window.history.pushState({}, '', href);
      render();
    });
  });

  const toggle = document.querySelector('.menu-toggle');
  const mobileNav = document.querySelector('.mobile-nav');
  if (toggle && mobileNav) {
    toggle.addEventListener('click', () => {
      const open = document.body.classList.toggle('menu-open');
      toggle.setAttribute('aria-expanded', String(open));
      toggle.innerHTML = icon(open ? 'close' : 'menu', 22);
      mobileNav.setAttribute('aria-hidden', String(!open));
    });
  }

  document.querySelectorAll('.filter-button').forEach((button) => button.addEventListener('click', () => {
    document.querySelectorAll('.filter-button').forEach((item) => item.classList.remove('is-active'));
    button.classList.add('is-active');
    const filter = button.dataset.filter;
    document.querySelectorAll('.directory-grid .business-card').forEach((card, index) => {
      const bucket = index < 3 ? 'ideas' : index < 6 ? 'people' : 'enterprise';
      card.style.display = filter === 'all' || filter === bucket ? '' : 'none';
    });
  }));

  const revealObserver = new IntersectionObserver((entries) => entries.forEach((entry) => {
    if (entry.isIntersecting) entry.target.classList.add('is-visible');
  }), { threshold: 0.08 });
  document.querySelectorAll('.reveal').forEach((el) => revealObserver.observe(el));
};

window.addEventListener('popstate', render);
render();
