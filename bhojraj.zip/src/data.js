export const contact = {
  phone: '9203936266',
  phoneDisplay: '+91 92039 36266',
  email: 'arjunkbhojraj@gmail.com',
  whatsapp: 'https://wa.me/919203936266'
};

export const businesses = [
  {
    slug: 'media',
    index: '01',
    label: 'Media',
    kicker: 'Stories with momentum',
    short: 'A modern media platform for ideas, people, and the conversations shaping tomorrow.',
    description: 'Bhojraj India Media creates considered spaces for brands, communities, and changemakers to be seen, heard, and remembered. From editorial storytelling to purposeful communication, the work balances clarity with cultural relevance.',
    promise: 'Make the signal impossible to miss.',
    stats: [['01', 'Editorial direction'], ['02', 'Brand storytelling'], ['03', 'Digital presence']],
    accent: 'blue',
    glyph: '↗'
  },
  {
    slug: 'news',
    index: '02',
    label: 'News',
    kicker: 'Context over noise',
    short: 'Independent, relevant news coverage designed to inform with clarity and intent.',
    description: 'The group’s news vertical is built around responsible reporting, local insight, and a sharp editorial point of view. It connects the detail on the ground to the larger story, helping readers move from information to understanding.',
    promise: 'Bring perspective to the day.',
    stats: [['01', 'Current affairs'], ['02', 'Local intelligence'], ['03', 'Digital publishing']],
    accent: 'gold',
    glyph: '◌'
  },
  {
    slug: 'constructions',
    index: '03',
    label: 'Constructions',
    kicker: 'Built for what’s next',
    short: 'A construction practice grounded in dependable execution and long-view thinking.',
    description: 'Bhojraj Constructions brings discipline, coordination, and a practical eye to the built environment. Every engagement is approached as a promise to the people who will live, work, and grow within it.',
    promise: 'Turn ambition into something tangible.',
    stats: [['01', 'Project coordination'], ['02', 'Site execution'], ['03', 'Built environments']],
    accent: 'clay',
    glyph: '▧'
  },
  {
    slug: 'workforce',
    index: '04',
    label: 'Workforce',
    kicker: 'People power progress',
    short: 'Manpower solutions that connect capability with the work that matters.',
    description: 'The workforce business helps organizations build responsive, capable teams through a people-first approach to manpower supply and coordination. The focus is simple: the right talent, prepared well, and supported throughout the journey.',
    promise: 'Put the right people in motion.',
    stats: [['01', 'Manpower supply'], ['02', 'Workforce planning'], ['03', 'Team readiness']],
    accent: 'mint',
    glyph: '✳'
  },
  {
    slug: 'magazine',
    index: '05',
    label: 'Magazine',
    kicker: 'A point of view in print',
    short: 'A curated editorial platform for culture, enterprise, and the people moving India forward.',
    description: 'The magazine is where the group slows down to explore ideas in depth. It pairs polished storytelling with a distinctly Indian sense of place, creating a thoughtful record of the work and the worlds around it.',
    promise: 'Give good ideas room to breathe.',
    stats: [['01', 'Long-form editorial'], ['02', 'Culture & enterprise'], ['03', 'Print & digital']],
    accent: 'rose',
    glyph: '▤'
  },
  {
    slug: 'podcast',
    index: '06',
    label: 'Podcast',
    kicker: 'Conversations with range',
    short: 'Unscripted conversations with the people, ideas, and journeys worth carrying forward.',
    description: 'The podcast opens a more personal door into the group’s ecosystem. Leaders, builders, creators, and citizens share the thinking behind the work — with space for nuance, candour, and a little healthy disagreement.',
    promise: 'Leave the room with a new question.',
    stats: [['01', 'Founder stories'], ['02', 'Industry conversations'], ['03', 'Ideas in motion']],
    accent: 'violet',
    glyph: '◉'
  },
  {
    slug: 'foods',
    index: '07',
    label: 'Foods',
    kicker: 'Everyday, with more care',
    short: 'Food ventures built around trust, quality, and the pleasure of sharing well.',
    description: 'Bhojraj Foods brings an entrepreneurial eye to the food ecosystem — from sourcing and trade to products that earn a place in everyday life. The standard is high, the approach is grounded, and the ambition is built to travel.',
    promise: 'Make quality feel close to home.',
    stats: [['01', 'Food ventures'], ['02', 'Quality sourcing'], ['03', 'Trade & distribution']],
    accent: 'orange',
    glyph: '⊹'
  },
  {
    slug: 'industries',
    index: '08',
    label: 'Industries',
    kicker: 'Systems that scale',
    short: 'Industrial thinking for businesses that want a stronger operating rhythm.',
    description: 'The industries vertical brings the group’s commercial curiosity into the systems, products, and partnerships that help businesses scale. It is practical, future-facing, and anchored in doing the fundamentals exceptionally well.',
    promise: 'Find the next useful edge.',
    stats: [['01', 'Industrial ventures'], ['02', 'Partnership models'], ['03', 'Operating systems']],
    accent: 'steel',
    glyph: '⌘'
  },
  {
    slug: 'global-trade',
    index: '09',
    label: 'Global Trade',
    kicker: 'Local roots. Wider reach.',
    short: 'Export and import partnerships that move opportunity across borders with confidence.',
    description: 'Bhojraj Global Trade connects Indian capability with international opportunity across export, import, sourcing, and distribution. Every relationship is shaped by reliability, transparency, and a clear understanding of the market at both ends.',
    promise: 'Make distance work in your favour.',
    stats: [['01', 'Export & import'], ['02', 'Cross-border sourcing'], ['03', 'Trade partnerships']],
    accent: 'cyan',
    glyph: '↗'
  }
];

export const getBusiness = (slug) => businesses.find((business) => business.slug === slug);
